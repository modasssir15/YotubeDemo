using EntityFrameworkCore.Triggers;
using Microsoft.EntityFrameworkCore;
using YouTube.DemoModule.Core.Models;

namespace YouTube.DemoModule.Data.Repositories
{
    public class YouTubeDemoModuleDbContext : DbContextWithTriggers
    {
        public YouTubeDemoModuleDbContext(DbContextOptions<YouTubeDemoModuleDbContext> options)
            : base(options)
        {
        }

        protected YouTubeDemoModuleDbContext(DbContextOptions options)
            : base(options)
        {
        }
        public YouTubeDemoModuleDbContext() : base()
        {
        }
        public DbSet<YoutubeVideo> Videos { get; set; }

        public DbSet<YoutubeVideo> YouTubeDemo { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=(local);Initial Catalog=VirtoCommerce3;Persist Security Info=True;MultipleActiveResultSets=True;User ID=sa;Password=password1$;Connect Timeout=30;User Id = sa;Password = password1$");
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<YoutubeVideo>().ToTable("YouTubeDemo").HasKey(x => x.Id);
            modelBuilder.Entity<YoutubeVideo>().Property(x => x.Id).HasMaxLength(128);
            base.OnModelCreating(modelBuilder);
        }
    }
}

