﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VirtoCommerce.Platform.Data.Infrastructure;
using YouTube.DemoModule.Core.Models;

namespace YouTube.DemoModule.Data.Repositories
{
    public class YoutubeRepository : DbContextRepositoryBase<YouTubeDemoModuleDbContext>, IYoutubeRepository
    {

        public YoutubeRepository(YouTubeDemoModuleDbContext context) : base(context)
        {

        }

        public IQueryable<YoutubeVideo> YoutubeVideos => DbContext.Set<YoutubeVideo>();
    }
}
