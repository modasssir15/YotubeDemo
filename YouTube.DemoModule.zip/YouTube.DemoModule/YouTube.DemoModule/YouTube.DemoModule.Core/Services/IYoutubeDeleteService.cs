﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YouTube.DemoModule.Core.Services
{
    public interface IYoutubeDeleteService
    {

        public string Delete(string id);
    }
}
