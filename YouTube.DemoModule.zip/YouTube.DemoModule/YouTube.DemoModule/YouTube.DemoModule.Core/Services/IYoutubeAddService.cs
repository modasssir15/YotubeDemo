﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using YouTube.DemoModule.Core.Models;

namespace YouTube.DemoModule.Core.Services
{
    public interface IYoutubeAddService
    {

        public string Add(YoutubeVideo sample);
        Task<string> Addition(YoutubeVideo video);
    }
}
